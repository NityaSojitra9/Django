from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('welcome/', views.welcome, name='welcome'),
    path('add/', views.add_song, name='add_song'),
    path('edit/<int:song_id>/', views.edit_song, name='edit_song'),
    path('delete/<int:song_id>/', views.delete_song, name='delete_song'),
    path('info/<int:song_id>/', views.song_info, name='song_info'),
]
