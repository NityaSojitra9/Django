from django.shortcuts import render, redirect, get_object_or_404
from .models import Song

def home(request):
    query = request.GET.get('q', '')
    if query:
        songs = Song.objects.filter(song_name__icontains=query) | Song.objects.filter(artist_name__icontains=query)
    else:
        songs = Song.objects.all()
    return render(request, 'home.html', {'songs': songs, 'query': query})

def welcome(request):
    return render(request, 'welcome.html')

def add_song(request):
    if request.method == 'POST':
        Song.objects.create(
            song_name=request.POST['song_name'],
            artist_name=request.POST['artist_name'],
            release_date=request.POST['release_date'],
            url=request.POST['url'],
            views=request.POST['views'],
        )
        return redirect('home')
    return render(request, 'add_song.html')

def edit_song(request, song_id):
    song = get_object_or_404(Song, pk=song_id)
    if request.method == 'POST':
        song.song_name = request.POST['song_name']
        song.artist_name = request.POST['artist_name']
        song.release_date = request.POST['release_date']
        song.url = request.POST['url']
        song.views = request.POST['views']
        song.save()
        return redirect('home')
    return render(request, 'edit_song.html', {'song': song})

def delete_song(request, song_id):
    song = get_object_or_404(Song, pk=song_id)
    song.delete()
    return redirect('home')

def song_info(request, song_id):
    song = get_object_or_404(Song, pk=song_id)
    return render(request, 'song_info.html', {'song': song})
